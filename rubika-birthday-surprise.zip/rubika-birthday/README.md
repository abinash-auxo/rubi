# Happy Birthday, Rubika: an interactive birthday surprise

A mobile-first, eight-chapter birthday website built with React, Vite, TypeScript,
Tailwind CSS, Framer Motion and Lucide icons. No backend, no paid services.

## 1. Install and run

You need Node.js 18 or newer (https://nodejs.org).

```bash
cd rubika-birthday
npm install
npm run dev          # opens a local preview, usually http://localhost:5173
```

To see it on your phone while you work, run `npm run dev -- --host` and open the
"Network" address it prints (your phone must be on the same Wi-Fi).

## 2. Personalize it (one file)

Open **`src/data/birthdayConfig.ts`**. Every word she reads is in that file:
the greeting, the love letter, the wishes, the "things worth celebrating" cards,
photo captions, the treasure hunt messages, the final message and the music path.
Each section has a comment explaining what to change. Edit the text between the
quotes, save, and the page updates.

The letter is under `letter:` (one paragraph per line in `paragraphs`).
The last message she sees is `finale.finalPersonalMessage`: write something only you could say.

## 3. Add your photos

1. Copy up to six photos into **`public/images/`**.
2. Name them `photo-1.jpg` ... `photo-6.jpg` (or change the `src` lines in the config).
3. Optionally write a caption and a short `alt` description for each in the config.

Resize photos to about 1600px wide first so they load quickly on a phone. Slots
with no photo show a tasteful placeholder, so the page never looks broken.

## 4. Add optional music

Put a file called **`birthday.mp3`** in **`public/audio/`** (or change `music.src`).
Only use music you have the right to use: your own recording, a royalty-free
track, or one whose licence allows it. Music never autoplays; she presses play.
If the file is missing, the button politely says music isn't available.

## 5. Build and deploy for free

```bash
npm run build        # creates the finished site in the dist/ folder
```

Any of these free hosts work (the site uses relative paths, so sub-folders are fine):

- **Netlify Drop (easiest):** go to https://app.netlify.com/drop and drag the `dist` folder onto the page.
- **Cloudflare Pages / Vercel:** connect a GitHub repo, build command `npm run build`, output folder `dist`.
- **GitHub Pages:** push the repo, then publish the `dist` folder (for example with the `gh-pages` package or a GitHub Action).

Privacy note: anyone with the link can open the site, including your photos and
letter. Don't put anything in it you wouldn't want a stranger to see, and share
the link only with her. The page asks search engines not to index it.

## 6. Test checklist

**On a phone (iPhone Safari and Android Chrome if you can):**
- [ ] The opening envelope appears; "Open Your Surprise" and "Skip intro" both work.
- [ ] The hero fits on screen, both buttons are tappable, confetti appears.
- [ ] "Make a Birthday Wish" opens a dialog; candles go out; Close works.
- [ ] The letter opens, types out, "Show the whole letter" works, "Keep This Letter Close" shows hearts.
- [ ] Every star opens a wish, including the golden "One Last Wish".
- [ ] All six cards flip and flip back.
- [ ] Photos open full screen; swipe left/right changes photo; close works.
- [ ] Treasure hunt: dragging a finger lights the sky; hint, skip and start over work; the gift opens.
- [ ] Finale: Light, Wish, Blow out, Celebrate in order; replay works.
- [ ] Music button plays/pauses (if you added a track) or shows the polite message (if not).
- [ ] The chapter dots at the bottom jump between chapters; nothing scrolls sideways.

**On desktop:**
- [ ] Chapter dots on the right edge work. Tab key reaches every button, with a visible gold focus ring.
- [ ] Escape closes dialogs; arrow keys change photos in the viewer.
- [ ] Turn on "Reduce motion" in your operating system: animations calm down and the letter appears instantly.

## 7. Project structure

```
src/
  data/birthdayConfig.ts      <- ALL editable content
  components/
    IntroScene.tsx            chapter 1: envelope
    BirthdayHero.tsx          chapter 2: reveal, cake, wish dialog
    LoveLetter.tsx            chapter 3: letter with typewriter
    WishConstellation.tsx     chapter 4: stars and wishes
    SpecialQualities.tsx      chapter 5: flip cards
    MemoryGallery.tsx         chapter 6: photos and lightbox
    TreasureHunt.tsx          chapter 7: flashlight mini-game
    BirthdayFinale.tsx        chapter 8: cake finale
    MusicPlayer.tsx, ProgressNavigation.tsx, Cake.tsx, EnvelopeGraphic.tsx,
    GiftBox.tsx, Modal.tsx, Petals.tsx, StarField.tsx, SectionHeading.tsx
  lib/   confetti.ts, motion.ts, asset.ts
  hooks/ useActiveSection.ts
  styles/index.css
public/images/   <- your photos
public/audio/    <- your music
```
