import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// base './' makes the built site work on any free host, even in a sub-folder.
export default defineConfig({
  base: './',
  plugins: [react()],
});
