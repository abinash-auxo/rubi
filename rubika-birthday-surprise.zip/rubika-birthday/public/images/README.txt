PUT YOUR PHOTOS HERE
--------------------
Copy up to six photos into this folder and name them:

  photo-1.jpg   photo-2.jpg   photo-3.jpg
  photo-4.jpg   photo-5.jpg   photo-6.jpg

If you use a different name or file type (.png, .webp), update the matching
"src" line in src/data/birthdayConfig.ts.

Tip: resize photos to about 1600px on the long edge so the page loads fast on a phone.
Until a photo exists, the gallery shows an elegant placeholder instead.
