PUT YOUR MUSIC HERE (OPTIONAL)
------------------------------
Copy an audio file here and name it:  birthday.mp3

Only use music you have the right to use (your own recording, a royalty-free
track, or a track whose licence allows this). If the file is missing, the page
still works and the music button politely says music isn't available.
To use another file name, change `music.src` in src/data/birthdayConfig.ts.
