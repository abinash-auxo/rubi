import { motion } from 'framer-motion';

interface Props { chapter: string; title: string; subtitle?: string }

export default function SectionHeading({ chapter, title, subtitle }: Props) {
  return (
    <motion.header
      className="mx-auto mb-10 max-w-2xl text-center"
      initial={{ opacity: 0, y: 18 }} whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }} transition={{ duration: 0.7 }}
    >
      <p className="mb-3 text-sm font-medium text-gold">{chapter}</p>
      <h2 className="text-4xl leading-tight text-ivory sm:text-5xl">{title}</h2>
      {subtitle && <p className="mt-4 text-base leading-relaxed text-ivory/80 sm:text-lg">{subtitle}</p>}
    </motion.header>
  );
}
