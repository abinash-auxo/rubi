import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { config } from '../data/birthdayConfig';
import EnvelopeGraphic from './EnvelopeGraphic';

type Phase = 'idle' | 'opening' | 'message';

/** Chapter 1: the mysterious invitation. */
export default function IntroScene({ onFinish }: { onFinish: () => void }) {
  const [phase, setPhase] = useState<Phase>('idle');
  const reduce = useReducedMotion();

  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    return () => { document.body.style.overflow = prev; };
  }, []);

  useEffect(() => {
    if (phase === 'opening') {
      const t = window.setTimeout(() => setPhase('message'), reduce ? 300 : 1700);
      return () => window.clearTimeout(t);
    }
    if (phase === 'message') {
      const t = window.setTimeout(onFinish, reduce ? 3000 : 4800);
      return () => window.clearTimeout(t);
    }
  }, [phase, onFinish, reduce]);

  const sparks = useMemo(
    () => Array.from({ length: 30 }, (_, i) => {
      const a = (i / 30) * Math.PI * 2 + Math.random() * 0.4;
      const d = 110 + Math.random() * 190;
      return { i, x: Math.cos(a) * d, y: Math.sin(a) * d, s: 3 + Math.random() * 5, dur: 1.2 + Math.random() * 0.9, c: ['#f9a8c6', '#e8c785', '#cdbdf2', '#fbf3e6'][i % 4] };
    }), []);

  return (
    <motion.div
      className="fixed inset-0 z-[60] flex flex-col items-center justify-center overflow-hidden bg-night-950/85 px-6 text-center"
      initial={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.9 }}
      aria-label="Opening scene"
    >
      <div aria-hidden="true" className="pointer-events-none absolute left-1/2 top-[38%] h-[460px] w-[460px] -translate-x-1/2 -translate-y-1/2 rounded-full animate-glow"
        style={{ background: 'radial-gradient(circle, rgba(240,112,159,.38), rgba(157,134,214,.14) 55%, transparent 72%)' }} />

      <button type="button" onClick={onFinish} className="btn btn-ghost absolute right-4 top-[max(1rem,env(safe-area-inset-top))] !min-h-[44px] !px-4 !py-2 text-sm">
        Skip intro
      </button>

      <div className="relative">
        <EnvelopeGraphic open={phase !== 'idle'} label={config.recipientName} className="animate-float" />
        {phase !== 'idle' && !reduce && sparks.map((s) => (
          <motion.span key={s.i} aria-hidden="true" className="absolute left-1/2 top-1/2 rounded-full"
            style={{ width: s.s, height: s.s, background: s.c, boxShadow: `0 0 10px ${s.c}` }}
            initial={{ x: 0, y: 0, opacity: 1, scale: 1 }} animate={{ x: s.x, y: s.y, opacity: 0, scale: 0.3 }}
            transition={{ duration: s.dur, delay: 0.5, ease: 'easeOut' }} />
        ))}
      </div>

      <div className="relative mt-12 flex min-h-[170px] max-w-md flex-col items-center">
        <AnimatePresence mode="wait">
          {phase === 'message' ? (
            <motion.div key="msg" initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="flex flex-col items-center gap-6">
              <h1 className="font-serif text-3xl leading-snug text-ivory sm:text-4xl" aria-live="polite">{config.intro.afterOpen}</h1>
              <button type="button" onClick={onFinish} className="btn btn-gold">Continue</button>
            </motion.div>
          ) : (
            <motion.div key="idle" exit={{ opacity: 0 }} className="flex flex-col items-center gap-6">
              <p className="text-base text-ivory/85 sm:text-lg">{config.intro.teaser}</p>
              <button type="button" disabled={phase !== 'idle'} onClick={() => setPhase('opening')} className="btn btn-primary">
                {config.intro.button}
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}
