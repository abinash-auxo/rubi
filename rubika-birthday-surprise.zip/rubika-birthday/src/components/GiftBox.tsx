import { useId } from 'react';
import { motion } from 'framer-motion';

/** Golden gift box. When `open` the lid lifts and light rays appear. */
export default function GiftBox({ open, className = '' }: { open: boolean; className?: string }) {
  const uid = useId().replace(/:/g, '');
  return (
    <svg viewBox="0 0 200 190" className={className} role="img" aria-label={open ? 'An open golden gift box' : 'A golden gift box'}>
      <defs>
        <linearGradient id={`g-${uid}`} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#f6dfae" /><stop offset="1" stopColor="#c9a15a" /></linearGradient>
        <linearGradient id={`b-${uid}`} x1="0" x2="0" y1="1" y2="0"><stop offset="0" stopColor="#ffe9a8" stopOpacity=".9" /><stop offset="1" stopColor="#ffe9a8" stopOpacity="0" /></linearGradient>
      </defs>
      <motion.polygon points="70,92 130,92 175,5 25,5" fill={`url(#b-${uid})`}
        initial={false} animate={{ opacity: open ? 1 : 0 }} transition={{ duration: 0.8, delay: 0.3 }} />
      {open && [[40, 30], [160, 24], [100, 8], [58, 60], [146, 62]].map(([x, y], i) => (
        <motion.path key={i} d={`M${x} ${y - 7} L${x + 2} ${y - 2} L${x + 7} ${y} L${x + 2} ${y + 2} L${x} ${y + 7} L${x - 2} ${y + 2} L${x - 7} ${y} L${x - 2} ${y - 2} Z`}
          fill="#fff4c9" initial={{ opacity: 0, scale: 0 }} animate={{ opacity: [0, 1, 0.6], scale: 1 }}
          transition={{ delay: 0.4 + i * 0.12, duration: 0.6 }} style={{ transformBox: 'fill-box', transformOrigin: 'center' }} />
      ))}
      <rect x="40" y="92" width="120" height="82" rx="6" fill={`url(#g-${uid})`} />
      <rect x="92" y="92" width="16" height="82" fill="#c2417a" />
      <ellipse cx="100" cy="182" rx="70" ry="6" fill="#000" opacity=".25" />
      <motion.g initial={false} animate={open ? { rotate: -24, y: -26, x: -8 } : { rotate: 0, y: 0, x: 0 }}
        transition={{ duration: 0.7, ease: 'easeOut' }} style={{ transformBox: 'fill-box', transformOrigin: 'left bottom' }}>
        <rect x="32" y="68" width="136" height="26" rx="5" fill={`url(#g-${uid})`} />
        <rect x="92" y="68" width="16" height="26" fill="#c2417a" />
        <path d="M100 68 C84 40 62 52 78 64 C86 70 96 68 100 68 Z" fill="#f0709f" />
        <path d="M100 68 C116 40 138 52 122 64 C114 70 104 68 100 68 Z" fill="#f0709f" />
        <circle cx="100" cy="66" r="6" fill="#c2417a" />
      </motion.g>
    </svg>
  );
}
