import { useMemo, type CSSProperties } from 'react';
import { useReducedMotion } from 'framer-motion';

/** Slowly falling rose petals. Place inside a `relative overflow-hidden` section. */
export default function Petals({ count }: { count?: number }) {
  const reduce = useReducedMotion();
  const petals = useMemo(() => {
    const n = count ?? (typeof window !== 'undefined' && window.innerWidth < 640 ? 8 : 14);
    return Array.from({ length: n }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      size: 10 + Math.random() * 12,
      dur: 12 + Math.random() * 10,
      delay: -Math.random() * 20,
      drift: (Math.random() - 0.5) * 160,
      hue: Math.random() > 0.5 ? '#f9a8c6' : '#f0709f',
    }));
  }, [count]);

  if (reduce) return null;
  return (
    <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
      {petals.map((p) => (
        <span
          key={p.id}
          className="absolute top-0 block animate-petal"
          style={
            {
              left: `${p.left}%`, width: p.size, height: p.size * 1.3,
              background: `linear-gradient(135deg, ${p.hue}, #c2417a)`,
              borderRadius: '150% 0 150% 0', opacity: 0.8,
              animationDuration: `${p.dur}s`, animationDelay: `${p.delay}s`,
              '--drift': `${p.drift}px`,
            } as CSSProperties
          }
        />
      ))}
    </div>
  );
}
