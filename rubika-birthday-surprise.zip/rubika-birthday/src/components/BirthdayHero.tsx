import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { Sparkles, X } from 'lucide-react';
import { config } from '../data/birthdayConfig';
import { fireConfetti } from '../lib/confetti';
import { scrollToId } from '../lib/motion';
import Cake from './Cake';
import Modal from './Modal';
import Petals from './Petals';

/** The wish scene lives in its own component so it resets every time it opens. */
function WishScene({ onClose }: { onClose: () => void }) {
  const [blown, setBlown] = useState(false);
  const [smoke, setSmoke] = useState(false);

  const blow = () => {
    setBlown(true);
    setSmoke(true);
    fireConfetti({ count: 60, origin: { x: 0.5, y: 0.55 }, power: 0.8 });
    window.setTimeout(() => setSmoke(false), 2200);
  };

  return (
    <div className="glass relative w-full max-w-md rounded-3xl p-6 text-center sm:p-8">
      <button type="button" onClick={onClose} aria-label="Close" className="absolute right-3 top-3 grid h-11 w-11 place-items-center rounded-full text-ivory/80 hover:bg-white/10">
        <X className="h-5 w-5" />
      </button>
      <h2 className="mt-2 text-3xl text-ivory sm:text-4xl">{config.hero.wishTitle}</h2>
      <p className="mx-auto mt-3 max-w-xs text-base leading-relaxed text-ivory/85">{config.hero.wishInstructions}</p>
      <Cake lit={!blown} smoke={smoke} className="mx-auto mt-4 w-56" />
      <div className="mt-4 min-h-[88px]" aria-live="polite">
        {!blown ? (
          <button type="button" onClick={blow} className="btn btn-primary">Blow Out the Candles</button>
        ) : (
          <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.5 }} className="flex flex-col items-center gap-4">
            <p className="font-serif text-2xl italic text-gold-soft">{config.hero.wishAfter}</p>
            <button type="button" onClick={onClose} className="btn btn-ghost">Close</button>
          </motion.div>
        )}
      </div>
    </div>
  );
}

/** Chapter 2: the grand birthday reveal. */
export default function BirthdayHero() {
  const [wishOpen, setWishOpen] = useState(false);

  useEffect(() => {
    const t = window.setTimeout(() => fireConfetti({ origin: { x: 0.5, y: 0.55 } }), 900);
    return () => window.clearTimeout(t);
  }, []);

  return (
    <section id="hero" aria-labelledby="hero-title" className="relative flex min-h-[100svh] flex-col items-center justify-center overflow-hidden px-5 pb-28 pt-20 text-center sm:pt-24">
      <Petals />
      <div className="relative z-10 mx-auto flex w-full max-w-3xl flex-col items-center">
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2, duration: 0.8 }}
          className="mb-4 inline-flex items-center gap-2 text-base font-medium text-gold">
          <Sparkles className="h-4 w-4" aria-hidden="true" /> {config.birthday.display}
        </motion.p>
        <h1 id="hero-title" className="text-ivory">
          <motion.span className="block font-serif text-5xl leading-[1.05] sm:text-7xl"
            initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.9 }}>
            {config.hero.greetingLine}
          </motion.span>
          <motion.span className="block pb-3 pt-1 font-script text-[4.75rem] leading-[1.05] text-gold-gradient sm:text-[9rem]"
            initial={{ opacity: 0, scale: 0.9 }} animate={{ opacity: 1, scale: 1 }} transition={{ delay: 0.75, duration: 1 }}>
            {config.recipientName}!
          </motion.span>
        </h1>
        <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 1.3, duration: 0.9 }}
          className="mx-auto max-w-xl text-base leading-relaxed text-ivory/90 sm:text-xl">
          {config.hero.message}
        </motion.p>

        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 1.6, duration: 0.9 }}
          className="relative mt-5 flex w-full flex-col items-center sm:mt-10">
          <div aria-hidden="true" className="absolute top-[-4%] h-56 w-56 rounded-full sm:h-80 sm:w-80"
            style={{ background: 'radial-gradient(circle at 38% 34%, rgba(255,250,240,.95), rgba(246,223,174,.6) 52%, rgba(201,161,90,.14) 80%, transparent 100%)', boxShadow: '0 0 110px 30px rgba(246,223,174,.18)' }} />
          <Cake lit className="relative w-44 animate-float sm:w-72" />
        </motion.div>

        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 2, duration: 0.8 }}
          className="mt-6 flex w-full flex-col items-stretch sm:mt-10 justify-center gap-3 sm:w-auto sm:flex-row">
          <button type="button" className="btn btn-primary" onClick={() => scrollToId('letter')}>{config.hero.primaryButton}</button>
          <button type="button" className="btn btn-ghost" onClick={() => setWishOpen(true)}>{config.hero.wishButton}</button>
        </motion.div>
      </div>

      <Modal open={wishOpen} onClose={() => setWishOpen(false)} label="Make a birthday wish" className="w-full max-w-md">
        <WishScene onClose={() => setWishOpen(false)} />
      </Modal>
    </section>
  );
}
