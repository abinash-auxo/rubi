import { motion } from 'framer-motion';
import { Heart } from 'lucide-react';

interface Props { open: boolean; label?: string; className?: string }

/** A CSS envelope whose flap folds back and whose card slides out when `open` is true. */
export default function EnvelopeGraphic({ open, label, className = '' }: Props) {
  return (
    <div className={`relative mx-auto h-[190px] w-[280px] max-w-full ${className}`} style={{ perspective: 900 }} aria-hidden="true">
      <div className="absolute inset-0 rounded-md bg-gradient-to-b from-[#7a2a5e] to-[#4a1740] shadow-[0_24px_70px_rgba(240,112,159,0.28)]" />
      {/* card inside the envelope */}
      <motion.div
        className="absolute left-4 right-4 top-3 flex h-[150px] items-start justify-center rounded-sm bg-ivory pt-5 shadow-md"
        style={{ zIndex: 1 }} initial={false}
        animate={{ y: open ? -92 : 0 }} transition={{ delay: open ? 0.55 : 0, duration: 0.8, ease: 'easeOut' }}
      >
        <span className="font-script text-3xl text-[#5a2a63]">{label}</span>
      </motion.div>
      {/* front pocket */}
      <div className="absolute inset-0 rounded-md"
        style={{ zIndex: 2, clipPath: 'polygon(0 0, 50% 54%, 100% 0, 100% 100%, 0 100%)', background: 'linear-gradient(180deg,#a23a78,#6b2358)' }} />
      {/* flap */}
      <motion.div
        className="absolute left-0 right-0 top-0 h-[105px]"
        style={{ transformOrigin: 'top', clipPath: 'polygon(0 0, 100% 0, 50% 100%)', background: 'linear-gradient(180deg,#b4457f,#8c2f69)' }}
        initial={false}
        animate={{ rotateX: open ? 180 : 0, zIndex: open ? [3, 3, 0] : 3 }}
        transition={{ duration: 0.7, ease: 'easeInOut', times: [0, 0.5, 1] }}
      />
      {/* wax seal */}
      <motion.div
        className="absolute left-1/2 top-[84px] grid h-9 w-9 -translate-x-1/2 place-items-center rounded-full bg-gold text-rose-dark shadow-lg"
        style={{ zIndex: 4 }} initial={false} animate={{ opacity: open ? 0 : 1, scale: open ? 0.5 : 1 }} transition={{ duration: 0.3 }}
      >
        <Heart className="h-4 w-4" fill="currentColor" />
      </motion.div>
    </div>
  );
}
