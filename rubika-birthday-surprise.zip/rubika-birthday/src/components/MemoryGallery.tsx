import { useCallback, useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { Camera, ChevronLeft, ChevronRight, X } from 'lucide-react';
import { config } from '../data/birthdayConfig';
import { asset } from '../lib/asset';
import Modal from './Modal';
import SectionHeading from './SectionHeading';

type Status = 'loading' | 'loaded' | 'empty';

function Placeholder({ n }: { n: number }) {
  return (
    <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 bg-gradient-to-br from-night-700 to-night-900 p-4 text-center">
      <Camera className="h-9 w-9 text-gold/80" aria-hidden="true" />
      <p className="font-serif text-xl text-ivory">Your photo goes here</p>
      <p className="text-sm text-ivory/70">Photo {n}</p>
    </div>
  );
}

/** Chapter 6: the photo gallery. Photos are set in src/data/birthdayConfig.ts */
export default function MemoryGallery() {
  const G = config.gallery;
  const [status, setStatus] = useState<Status[]>(() => G.items.map((it) => (it.src ? 'loading' : 'empty')));
  const [open, setOpen] = useState<number | null>(null);
  const touchX = useRef<number | null>(null);

  const setS = (i: number, s: Status) => setStatus((prev) => prev.map((v, k) => (k === i ? s : v)));
  const loaded = G.items.map((_, i) => i).filter((i) => status[i] === 'loaded');

  const step = useCallback((dir: 1 | -1) => {
    setOpen((cur) => {
      if (cur === null || loaded.length === 0) return cur;
      const pos = loaded.indexOf(cur);
      return loaded[(pos + dir + loaded.length) % loaded.length];
    });
  }, [loaded]);

  useEffect(() => {
    if (open === null) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight') step(1);
      if (e.key === 'ArrowLeft') step(-1);
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [open, step]);

  const current = open !== null ? G.items[open] : null;

  return (
    <section id="gallery" aria-label="Photo gallery" className="relative px-5 py-24 pb-28">
      <SectionHeading chapter="Chapter 6" title={G.heading} subtitle={G.subtitle} />
      <ul className="mx-auto grid max-w-4xl list-none grid-cols-2 gap-4 p-0 sm:gap-6 md:grid-cols-3">
        {G.items.map((item, i) => {
          const ok = status[i] === 'loaded';
          const frame = (
            <span className="relative block aspect-[4/5] w-full overflow-hidden rounded-[19px] bg-night-800">
              {status[i] !== 'loaded' && <Placeholder n={i + 1} />}
              {item.src && status[i] !== 'empty' && (
                <img src={asset(item.src)} alt={item.alt} loading="lazy" draggable={false}
                  onLoad={() => setS(i, 'loaded')} onError={() => setS(i, 'empty')}
                  className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ${ok ? 'opacity-100' : 'opacity-0'}`} />
              )}
              <span aria-hidden="true" className="pointer-events-none absolute inset-0 bg-[radial-gradient(transparent_55%,rgba(7,3,15,0.55))]" />
            </span>
          );
          return (
            <motion.li key={i} initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-40px' }} transition={{ duration: 0.6, delay: (i % 3) * 0.1 }}>
              <figure className="m-0">
                <div className="rounded-[22px] bg-gradient-to-br from-gold/80 via-rose/50 to-lav/70 p-[3px] shadow-[0_20px_50px_rgba(0,0,0,0.4)]">
                  {ok ? (
                    <button type="button" onClick={() => setOpen(i)} aria-label={`Open photo ${i + 1} full screen`}
                      className="block w-full overflow-hidden rounded-[19px] transition-transform duration-300 hover:scale-[1.02] active:scale-[0.98]">
                      {frame}
                    </button>
                  ) : frame}
                </div>
                {item.caption && <figcaption className="mt-3 text-center font-serif text-lg italic text-ivory/90">{item.caption}</figcaption>}
              </figure>
            </motion.li>
          );
        })}
      </ul>

      <Modal open={open !== null} onClose={() => setOpen(null)} label="Photo viewer" className="relative flex h-full w-full max-w-3xl flex-col items-center justify-center">
        {current && (
          <div className="flex max-h-full w-full flex-col items-center gap-3"
            onTouchStart={(e) => { touchX.current = e.touches[0].clientX; }}
            onTouchEnd={(e) => {
              if (touchX.current === null) return;
              const dx = e.changedTouches[0].clientX - touchX.current;
              touchX.current = null;
              if (Math.abs(dx) > 50) step(dx < 0 ? 1 : -1);
            }}>
            <img src={asset(current.src)} alt={current.alt} className="max-h-[75svh] w-auto max-w-full rounded-xl object-contain shadow-2xl" />
            {current.caption && <p className="text-center font-serif text-xl italic text-ivory">{current.caption}</p>}
            <p className="text-sm text-ivory/75">{loaded.indexOf(open as number) + 1} of {loaded.length}</p>
          </div>
        )}
        <button type="button" onClick={() => setOpen(null)} aria-label="Close photo viewer" className="absolute right-0 top-0 grid h-12 w-12 place-items-center rounded-full bg-night-900/80 text-ivory">
          <X className="h-6 w-6" />
        </button>
        {loaded.length > 1 && (
          <>
            <button type="button" onClick={() => step(-1)} aria-label="Previous photo" className="absolute left-0 top-1/2 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full bg-night-900/80 text-ivory">
              <ChevronLeft className="h-6 w-6" />
            </button>
            <button type="button" onClick={() => step(1)} aria-label="Next photo" className="absolute right-0 top-1/2 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full bg-night-900/80 text-ivory">
              <ChevronRight className="h-6 w-6" />
            </button>
          </>
        )}
      </Modal>
    </section>
  );
}
