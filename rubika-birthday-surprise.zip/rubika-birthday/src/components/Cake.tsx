import { useId } from 'react';
import { AnimatePresence, motion } from 'framer-motion';

const CANDLES = [
  { x: 118, c: '#f9a8c6' }, { x: 139, c: '#e8c785' }, { x: 160, c: '#cdbdf2' },
  { x: 181, c: '#e8c785' }, { x: 202, c: '#f9a8c6' },
];
const baseY = (x: number) => 104 + 8 * Math.sqrt(Math.max(0, 1 - ((x - 160) / 60) ** 2));

function pearls(cx: number, cy: number, rx: number, ry: number, drop: number, n: number) {
  return Array.from({ length: n }, (_, i) => {
    const t = Math.PI * (i / (n - 1));
    return { x: cx + rx * Math.cos(t), y: cy + ry * Math.sin(t) + drop };
  });
}

interface Props { lit: boolean; smoke?: boolean; className?: string }

/** A three-tier cake drawn in SVG with a soft 3D look. `lit` shows the flames. */
export default function Cake({ lit, smoke = false, className = '' }: Props) {
  const uid = useId().replace(/:/g, '');
  const id = (n: string) => `${n}-${uid}`;
  return (
    <svg viewBox="0 0 320 310" className={className} role="img" aria-label={lit ? 'Birthday cake with lit candles' : 'Birthday cake'}>
      <defs>
        <linearGradient id={id('rose')} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#f9a8c6" /><stop offset="1" stopColor="#b8386f" /></linearGradient>
        <linearGradient id={id('ivory')} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#fff8ec" /><stop offset="1" stopColor="#cdbdf2" /></linearGradient>
        <linearGradient id={id('gold')} x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="#f6dfae" /><stop offset="1" stopColor="#c9a15a" /></linearGradient>
        <linearGradient id={id('plate')} x1="0" x2="1" y1="0" y2="0"><stop offset="0" stopColor="#b8913f" /><stop offset=".5" stopColor="#f6dfae" /><stop offset="1" stopColor="#b8913f" /></linearGradient>
        <radialGradient id={id('glow')}><stop offset="0" stopColor="#ffe9a8" stopOpacity=".95" /><stop offset="1" stopColor="#ffb86b" stopOpacity="0" /></radialGradient>
      </defs>
      <ellipse cx="160" cy="288" rx="146" ry="20" fill={`url(#${id('plate')})`} />
      <ellipse cx="160" cy="284" rx="132" ry="16" fill="#2a1857" opacity=".35" />
      {/* bottom tier */}
      <path d="M40 205 v62 a120 26 0 0 0 240 0 v-62 z" fill={`url(#${id('rose')})`} />
      <ellipse cx="160" cy="205" rx="120" ry="26" fill="#ffd1e1" />
      {pearls(160, 205, 112, 24, 10, 15).map((p, i) => <circle key={i} cx={p.x} cy={p.y} r="3.2" fill="#fbf3e6" opacity=".9" />)}
      {/* middle tier */}
      <path d="M70 150 v55 a90 20 0 0 0 180 0 v-55 z" fill={`url(#${id('ivory')})`} />
      <ellipse cx="160" cy="150" rx="90" ry="20" fill="#ffffff" />
      {pearls(160, 150, 84, 18, 9, 11).map((p, i) => <circle key={i} cx={p.x} cy={p.y} r="2.8" fill="#e8c785" />)}
      {/* top tier */}
      <path d="M100 105 v45 a60 14 0 0 0 120 0 v-45 z" fill={`url(#${id('gold')})`} />
      <ellipse cx="160" cy="105" rx="60" ry="14" fill="#fff1cf" />
      {pearls(160, 105, 55, 12, 8, 9).map((p, i) => <circle key={i} cx={p.x} cy={p.y} r="2.4" fill="#c2417a" />)}
      {/* candles */}
      {CANDLES.map((c) => {
        const b = baseY(c.x);
        return (
          <g key={c.x}>
            <rect x={c.x - 4} y={b - 40} width="8" height="40" rx="3" fill={c.c} />
            <rect x={c.x - 4} y={b - 40} width="3" height="40" rx="1.5" fill="#ffffff" opacity=".35" />
            <line x1={c.x} x2={c.x} y1={b - 40} y2={b - 46} stroke="#4a2a5a" strokeWidth="1.6" strokeLinecap="round" />
          </g>
        );
      })}
      <AnimatePresence>
        {lit && CANDLES.map((c, i) => {
          const y = baseY(c.x) - 52;
          return (
            <motion.g key={c.x} transform={`translate(${c.x} ${y})`}
              initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.35, delay: i * 0.08 }}>
              <circle r="17" fill={`url(#${id('glow')})`} />
              <g className="flame">
                <path d="M0 14 C-7 6 -5 -6 0 -16 C5 -6 7 6 0 14 Z" fill="#ffb347" />
                <path d="M0 13 C-3.5 8 -2.5 0 0 -6 C2.5 0 3.5 8 0 13 Z" fill="#fff4c9" />
              </g>
            </motion.g>
          );
        })}
      </AnimatePresence>
      {smoke && CANDLES.map((c, i) => (
        <motion.path key={`s${c.x}`} d={`M${c.x} ${baseY(c.x) - 48} q-6 -10 0 -20 q6 -10 0 -20`}
          fill="none" stroke="#cdbdf2" strokeWidth="2" strokeLinecap="round"
          initial={{ opacity: 0.7, y: 0 }} animate={{ opacity: 0, y: -26 }} transition={{ duration: 1.8, delay: i * 0.1, ease: 'easeOut' }} />
      ))}
    </svg>
  );
}
