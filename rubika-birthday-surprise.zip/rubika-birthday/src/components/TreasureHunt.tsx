import { useEffect, useRef, useState, type PointerEvent } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Gift, Heart, Lock, RotateCcw, SkipForward, Star, Lightbulb, Check } from 'lucide-react';
import { config } from '../data/birthdayConfig';
import { fireConfetti } from '../lib/confetti';
import { prefersReducedMotion } from '../lib/motion';
import GiftBox from './GiftBox';
import SectionHeading from './SectionHeading';

type Id = 'heart' | 'star' | 'gift';
interface Pos { x: number; y: number }
const GIFT_POS: Pos = { x: 50, y: 84 };
const ORDER: Id[] = ['heart', 'star', 'gift'];

function makePositions(): Record<'heart' | 'star', Pos> {
  const pick = (): Pos => ({ x: 12 + Math.random() * 76, y: 14 + Math.random() * 52 });
  const a = pick();
  let b = pick();
  for (let t = 0; t < 60 && Math.hypot(a.x - b.x, (a.y - b.y) * 1.4) < 30; t++) b = pick();
  return { heart: a, star: b };
}

function describe(p: Pos): string {
  const v = p.y < 30 ? 'top' : p.y > 52 ? 'bottom' : 'middle';
  const h = p.x < 35 ? 'left' : p.x > 65 ? 'right' : 'center';
  if (v === 'middle' && h === 'center') return 'close to the middle of the sky';
  if (v === 'middle') return `on the ${h} side, around the middle`;
  if (h === 'center') return `near the ${v} of the sky, around the center`;
  return `in the ${v} ${h} area`;
}

/** Mounts closed, then opens the lid so the animation is always seen. */
function GiftReveal() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const t = window.setTimeout(() => setOpen(true), 500);
    return () => window.clearTimeout(t);
  }, []);
  return <GiftBox open={open} className="w-48 sm:w-56" />;
}

const BLANK: Record<Id, boolean> = { heart: false, star: false, gift: false };

/** Chapter 7: a tiny treasure hunt. Move a "flashlight" over the sky to find hidden things. */
export default function TreasureHunt() {
  const T = config.treasure;
  const fieldRef = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState(makePositions);
  const [found, setFound] = useState<Record<Id, boolean>>(BLANK);
  const [message, setMessage] = useState('');
  const [hint, setHint] = useState('');
  const [shake, setShake] = useState(0);
  const finished = found.gift;
  const finalRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!finished) return;
    const t = window.setTimeout(() => finalRef.current?.scrollIntoView({ behavior: prefersReducedMotion() ? 'auto' : 'smooth', block: 'center' }), 900);
    return () => window.clearTimeout(t);
  }, [finished]);
  const count = ORDER.filter((k) => found[k]).length;
  const nextClue = T.clues.find((c) => !found[c.id]);
  const positionOf = (id: Id): Pos => (id === 'gift' ? GIFT_POS : pos[id]);

  const light = (x: number, y: number) => {
    fieldRef.current?.style.setProperty('--sx', `${x}px`);
    fieldRef.current?.style.setProperty('--sy', `${y}px`);
  };
  const onPointer = (e: PointerEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    light(e.clientX - r.left, e.clientY - r.top);
  };
  const lightOn = (id: Id) => {
    const r = fieldRef.current?.getBoundingClientRect();
    if (!r) return;
    const p = positionOf(id);
    light((p.x / 100) * r.width, (p.y / 100) * r.height);
  };

  const find = (id: Id) => {
    if (found[id]) return;
    if (id === 'gift' && !(found.heart && found.star)) {
      setMessage(T.lockedMessage);
      setShake((s) => s + 1);
      return;
    }
    setFound((f) => ({ ...f, [id]: true }));
    setHint('');
    setMessage(T.clues.find((c) => c.id === id)?.found ?? '');
    if (id === 'gift') window.setTimeout(() => fireConfetti({ origin: { x: 0.5, y: 0.6 } }), 500);
  };

  const showHint = () => {
    if (!nextClue) return;
    const id = nextClue.id;
    setHint(id === 'gift' ? 'The golden box is at the bottom. It unlocks once you have found the heart and the star.' : `Try looking ${describe(pos[id])}.`);
    if (id !== 'gift') lightOn(id);
    window.setTimeout(() => setHint(''), 6000);
  };
  const reset = () => { setPos(makePositions()); setFound(BLANK); setMessage(''); setHint(''); light(-300, -300); };
  const skip = () => { setFound({ heart: true, star: true, gift: true }); setMessage(''); setHint(''); fireConfetti({ origin: { x: 0.5, y: 0.6 } }); };

  const icons: Record<Id, typeof Heart> = { heart: Heart, star: Star, gift: Gift };
  const glow: Record<Id, string> = { heart: 'text-rose', star: 'text-gold', gift: 'text-gold' };

  return (
    <section id="treasure" aria-label="Treasure hunt" className="relative px-5 py-24 pb-28">
      <SectionHeading chapter="Chapter 7" title={T.title} subtitle={T.intro} />
      <div className="mx-auto max-w-2xl">
        <ol className="mb-5 flex items-center justify-center gap-2 p-0 sm:gap-4" aria-label={`Progress: ${count} of 3 found`}>
          {T.clues.map((c) => {
            const Icon = icons[c.id];
            return (
              <li key={c.id} className={`flex min-h-[44px] items-center gap-2 rounded-full border px-3 py-1.5 text-[13px] ${found[c.id] ? 'border-gold bg-gold/15 text-gold-soft' : 'border-ivory/30 text-ivory/80'}`}>
                {found[c.id] ? <Check className="h-4 w-4" aria-hidden="true" /> : <Icon className="h-4 w-4" aria-hidden="true" />}
                <span>{c.label}</span>
                <span className="sr-only">{found[c.id] ? 'found' : 'not found yet'}</span>
              </li>
            );
          })}
        </ol>
        <p className="mb-3 text-center text-sm text-ivory/80">{count} of 3 found</p>

        <div ref={fieldRef} onPointerMove={onPointer} onPointerDown={onPointer}
          className="relative h-[340px] touch-pan-y select-none overflow-hidden rounded-3xl border border-gold/30 bg-gradient-to-b from-night-700 to-night-950 sm:h-[400px]"
          style={{ ['--sx' as string]: '-300px', ['--sy' as string]: '-300px' }}>
          {/* dim "sky" speckles */}
          <div aria-hidden="true" className="absolute inset-0 opacity-60" style={{ backgroundImage: 'radial-gradient(1.5px 1.5px at 20% 30%, #fbf3e6 50%, transparent), radial-gradient(1px 1px at 70% 20%, #fbf3e6 50%, transparent), radial-gradient(1.5px 1.5px at 40% 75%, #fbf3e6 50%, transparent), radial-gradient(1px 1px at 85% 60%, #fbf3e6 50%, transparent), radial-gradient(1px 1px at 10% 80%, #fbf3e6 50%, transparent), radial-gradient(1.5px 1.5px at 60% 50%, #fbf3e6 50%, transparent)' }} />
          {(['heart', 'star'] as const).map((id) => {
            const Icon = icons[id];
            const p = pos[id];
            const isHint = hint !== '' && nextClue?.id === id;
            return (
              <button key={id} type="button" onClick={() => find(id)} onFocus={() => lightOn(id)}
                aria-label={`${T.clues.find((c) => c.id === id)?.label}${found[id] ? ' (found)' : ''}`}
                className={`absolute grid h-16 w-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full ${found[id] ? 'z-20' : 'z-0'}`}
                style={{ left: `${p.x}%`, top: `${p.y}%` }}>
                {isHint && <span aria-hidden="true" className="absolute h-16 w-16 animate-ping rounded-full border-2 border-gold" />}
                {found[id] && (
                  <motion.span aria-hidden="true" className="absolute h-14 w-14 rounded-full border-2 border-gold" initial={{ scale: 0.4, opacity: 1 }} animate={{ scale: 2.4, opacity: 0 }} transition={{ duration: 0.9 }} />
                )}
                <Icon className={`h-9 w-9 ${glow[id]} ${found[id] ? 'drop-shadow-[0_0_14px_currentColor]' : ''}`} fill="currentColor" aria-hidden="true" />
              </button>
            );
          })}
          {/* the spotlight: everything outside the circle of light stays dark */}
          <div aria-hidden="true" className="pointer-events-none absolute inset-0 z-10"
            style={{ background: 'radial-gradient(circle 120px at var(--sx) var(--sy), rgba(7,3,15,0) 0%, rgba(7,3,15,0) 38%, rgba(7,3,15,0.94) 100%)' }} />
          {/* the golden gift box, always visible, locked until heart + star are found */}
          <button key={shake} type="button" onClick={() => find('gift')} onFocus={() => lightOn('gift')}
            aria-label={`Golden gift box, ${found.heart && found.star ? 'unlocked' : 'locked'}`}
            className={`absolute z-20 grid h-[72px] w-[72px] -translate-x-1/2 -translate-y-1/2 place-items-center rounded-2xl border ${found.heart && found.star ? 'animate-glow border-gold bg-gold/20' : 'border-ivory/25 bg-night-900/70'} ${shake ? 'animate-shake' : ''}`}
            style={{ left: `${GIFT_POS.x}%`, top: `${GIFT_POS.y}%` }}>
            <Gift className={`h-9 w-9 ${found.heart && found.star ? 'text-gold' : 'text-ivory/50'}`} aria-hidden="true" />
            {!(found.heart && found.star) && <Lock className="absolute -right-1.5 -top-1.5 h-5 w-5 rounded-full bg-night-900 p-0.5 text-gold" aria-hidden="true" />}
          </button>
        </div>

        <div className="mt-5 min-h-[96px] text-center" aria-live="polite">
          {!finished && <p className="font-serif text-xl italic text-gold-soft sm:text-2xl">{nextClue?.prompt}</p>}
          {message && !finished && <p className="mt-2 text-base text-ivory/90">{message}</p>}
          {hint && <p className="mt-2 text-base text-ivory/90">{hint}</p>}
        </div>

        <div className="mt-4 flex flex-wrap items-center justify-center gap-3">
          <button type="button" className="btn btn-ghost" onClick={showHint} disabled={finished}><Lightbulb className="h-4 w-4" aria-hidden="true" /> Need a hint?</button>
          <button type="button" className="btn btn-ghost" onClick={skip} disabled={finished}><SkipForward className="h-4 w-4" aria-hidden="true" /> Skip to the surprise</button>
          <button type="button" className="btn btn-ghost" onClick={reset}><RotateCcw className="h-4 w-4" aria-hidden="true" /> Start over</button>
        </div>

        <AnimatePresence>
          {finished && (
            <motion.div key="final" ref={finalRef} initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.8 }}
              className="glass mt-8 flex flex-col items-center rounded-3xl p-6 text-center sm:p-8" aria-live="polite">
              <GiftReveal />
              <p className="mt-2 font-serif text-2xl italic leading-snug text-ivory sm:text-[1.7rem]">{T.finalMessage}</p>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}
