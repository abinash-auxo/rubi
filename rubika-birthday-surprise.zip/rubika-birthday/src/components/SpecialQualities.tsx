import { useState, type ComponentType } from 'react';
import { motion } from 'framer-motion';
import { Fingerprint, Flower2, Heart, Mountain, Smile, Sparkles, type LucideProps } from 'lucide-react';
import { config, type Quality } from '../data/birthdayConfig';
import SectionHeading from './SectionHeading';

const ICONS: Record<Quality['icon'], ComponentType<LucideProps>> = {
  smile: Smile, heart: Heart, sparkles: Sparkles, mountain: Mountain, fingerprint: Fingerprint, flower: Flower2,
};

function FlipCard({ item, index }: { item: Quality; index: number }) {
  const [flipped, setFlipped] = useState(false);
  const Icon = ICONS[item.icon];
  return (
    <motion.li initial={{ opacity: 0, y: 24 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-40px' }} transition={{ duration: 0.6, delay: (index % 3) * 0.1 }}>
      <button type="button" aria-pressed={flipped} onClick={() => setFlipped((f) => !f)}
        aria-label={`${item.title}. ${flipped ? 'Showing message, press to turn back.' : 'Press to reveal a message.'}`}
        className="block h-[230px] w-full text-left" style={{ perspective: 1000 }}>
        <span className="flip-inner relative block h-full w-full" style={{ transform: flipped ? 'rotateY(180deg)' : 'none' }}>
          <span aria-hidden={flipped} className="flip-face glass absolute inset-0 flex flex-col items-center justify-center gap-4 rounded-3xl p-5 text-center">
            <span className="grid h-16 w-16 place-items-center rounded-full bg-gradient-to-br from-rose-deep to-rose-dark text-white shadow-lg">
              <Icon className="h-8 w-8" aria-hidden="true" />
            </span>
            <span className="font-serif text-2xl leading-tight text-ivory">{item.title}</span>
            <span className="text-sm text-gold-soft">Tap to turn over</span>
          </span>
          <span aria-hidden={!flipped} className="flip-face absolute inset-0 flex flex-col items-center justify-center gap-3 rounded-3xl border border-gold/50 bg-gradient-to-br from-[#3b1a5e] to-[#1f1141] p-6 text-center shadow-[0_0_40px_rgba(232,199,133,0.18)]"
            style={{ transform: 'rotateY(180deg)' }}>
            <Icon className="h-6 w-6 text-gold" aria-hidden="true" />
            <span className="font-serif text-[1.35rem] italic leading-snug text-ivory">{item.message}</span>
          </span>
        </span>
      </button>
    </motion.li>
  );
}

/** Chapter 5: things worth celebrating. */
export default function SpecialQualities() {
  const Q = config.qualities;
  return (
    <section id="celebrate" aria-label="Things worth celebrating" className="relative px-5 py-24 pb-28">
      <SectionHeading chapter="Chapter 5" title={Q.heading} subtitle={Q.subtitle} />
      <ul className="mx-auto grid max-w-5xl list-none grid-cols-1 gap-5 p-0 sm:grid-cols-2 lg:grid-cols-3">
        {Q.items.map((item, i) => <FlipCard key={item.title} item={item} index={i} />)}
      </ul>
    </section>
  );
}
