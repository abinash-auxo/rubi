import { useEffect, useRef, useState } from 'react';
import { Pause, Play, Volume2, VolumeX } from 'lucide-react';
import { config } from '../data/birthdayConfig';
import { asset } from '../lib/asset';

/** Optional music. Never autoplays; a missing file never breaks the page. */
export default function MusicPlayer() {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(false);
  const [unavailable, setUnavailable] = useState(!config.music.src);

  useEffect(() => () => { audioRef.current?.pause(); }, []);

  const ensureAudio = () => {
    if (audioRef.current) return audioRef.current;
    const a = new Audio(asset(config.music.src));
    a.loop = true;
    a.volume = 0.6;
    a.preload = 'none';
    a.addEventListener('error', () => { setUnavailable(true); setPlaying(false); });
    audioRef.current = a;
    return a;
  };

  const toggle = async () => {
    if (unavailable) { setUnavailable(true); return; }
    const a = ensureAudio();
    if (playing) { a.pause(); setPlaying(false); return; }
    try {
      await a.play();
      setPlaying(true);
    } catch {
      setUnavailable(true);
      setPlaying(false);
    }
  };

  const toggleMute = () => {
    const a = audioRef.current;
    if (a) a.muted = !muted;
    setMuted((m) => !m);
  };

  return (
    <div className="fixed left-3 top-[max(0.75rem,env(safe-area-inset-top))] z-[70] flex flex-col items-start gap-2">
      <div className="glass flex items-center gap-1 rounded-full p-1">
        <button type="button" onClick={toggle} aria-pressed={playing}
          aria-label={playing ? 'Pause music' : 'Play music'}
          className="grid h-11 w-11 place-items-center rounded-full bg-gradient-to-br from-rose-deep to-rose-dark text-white">
          {playing ? <Pause className="h-5 w-5" fill="currentColor" /> : <Play className="h-5 w-5" fill="currentColor" />}
        </button>
        <button type="button" onClick={toggleMute} aria-pressed={muted}
          aria-label={muted ? 'Unmute music' : 'Mute music'}
          className="grid h-11 w-11 place-items-center rounded-full text-ivory hover:bg-white/10">
          {muted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5" />}
        </button>
        <span aria-hidden="true" className="mr-3 flex h-5 items-end gap-[3px]">
          {[0, 0.25, 0.5].map((d) => (
            <span key={d} className={`block h-full w-[3px] origin-bottom rounded-full bg-gold ${playing && !muted ? 'animate-bars' : 'scale-y-[.3]'}`} style={{ animationDelay: `${d}s` }} />
          ))}
        </span>
      </div>
      {unavailable && (
        <p role="status" className="glass max-w-[220px] rounded-xl px-3 py-2 text-[13px] text-ivory/90">{config.music.unavailableMessage}</p>
      )}
    </div>
  );
}
