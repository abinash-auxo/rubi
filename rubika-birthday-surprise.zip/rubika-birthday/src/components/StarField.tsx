import { useEffect, useRef } from 'react';

/** Twinkling night sky drawn on one lightweight canvas behind everything. */
export default function StarField() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let w = 0, h = 0, raf = 0, last = 0;
    let stars: { x: number; y: number; r: number; p: number; s: number }[] = [];

    const draw = (t: number) => {
      ctx.clearRect(0, 0, w, h);
      ctx.fillStyle = '#fbf3e6';
      for (const s of stars) {
        ctx.globalAlpha = reduce ? 0.7 : 0.3 + 0.7 * Math.abs(Math.sin((t / 1000) * s.s + s.p));
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, 6.2832);
        ctx.fill();
      }
    };

    const setup = () => {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      w = window.innerWidth; h = window.innerHeight;
      canvas.width = w * dpr; canvas.height = h * dpr;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      const n = Math.round(Math.min(110, (w * h) / 9000));
      stars = Array.from({ length: n }, () => ({
        x: Math.random() * w, y: Math.random() * h, r: 0.3 + Math.random() * 1.2,
        p: Math.random() * 6.28, s: 0.4 + Math.random() * 1.2,
      }));
      draw(0);
    };

    const loop = (t: number) => {
      if (t - last > 33) { draw(t); last = t; }
      raf = requestAnimationFrame(loop);
    };

    let lastW = window.innerWidth, lastH = window.innerHeight;
    const onResize = () => {
      // Phones fire resize while the address bar hides; ignore small height changes.
      if (window.innerWidth === lastW && Math.abs(window.innerHeight - lastH) < 140) return;
      lastW = window.innerWidth; lastH = window.innerHeight;
      setup();
    };

    setup();
    if (!reduce) raf = requestAnimationFrame(loop);
    window.addEventListener('resize', onResize);
    return () => { cancelAnimationFrame(raf); window.removeEventListener('resize', onResize); };
  }, []);

  return <canvas ref={ref} aria-hidden="true" className="pointer-events-none fixed inset-0 -z-10 h-full w-full" />;
}
