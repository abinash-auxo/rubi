import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Sparkles, Star } from 'lucide-react';
import { config } from '../data/birthdayConfig';
import SectionHeading from './SectionHeading';

const POS = [{ x: 14, y: 20 }, { x: 38, y: 9 }, { x: 64, y: 22 }, { x: 87, y: 11 }, { x: 22, y: 58 }, { x: 52, y: 48 }];
const GOLD = { x: 78, y: 74 };
const LINES = ['14,20 38,9 64,22 87,11', '14,20 22,58 52,48 64,22', '52,48 78,74'];

/** Chapter 4: a galaxy of wishes. */
export default function WishConstellation() {
  const W = config.wishes;
  const [selected, setSelected] = useState<number | null>(null); // 0-5 = wishes, 6 = golden
  const [seen, setSeen] = useState<Set<number>>(new Set());

  const open = (i: number) => {
    setSelected(i);
    setSeen((s) => new Set(s).add(i));
  };
  const text = selected === null ? null : selected === 6 ? W.lastWish : W.stars[selected].text;

  return (
    <section id="wishes" aria-label="Birthday wishes" className="relative px-5 py-24 pb-28">
      <SectionHeading chapter="Chapter 4" title={W.heading} subtitle={W.subtitle} />
      <div className="mx-auto max-w-2xl">
        <div className="glass overflow-hidden rounded-3xl">
          <div className="relative h-[330px] sm:h-[400px]">
          <svg aria-hidden="true" viewBox="0 0 100 100" preserveAspectRatio="none" className="absolute inset-0 h-full w-full">
            {LINES.map((seg, i) => (
              <polyline key={i} points={seg} fill="none" stroke="#e8c785" strokeOpacity=".4" strokeWidth="1" strokeDasharray="4 5" vectorEffect="non-scaling-stroke" />
            ))}
          </svg>
          {POS.map((p, i) => {
            const isSeen = seen.has(i);
            return (
              <button key={i} type="button" onClick={() => open(i)} aria-pressed={selected === i}
                aria-label={`Wish ${i + 1} of ${POS.length}${isSeen ? ', already opened' : ''}`}
                className="absolute grid h-14 w-14 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full transition-transform active:scale-90"
                style={{ left: `${p.x}%`, top: `${p.y}%` }}>
                <span className="relative grid place-items-center animate-twinkle" style={{ animationDelay: `${i * 0.4}s` }}>
                  <span aria-hidden="true" className={`absolute h-12 w-12 rounded-full blur-md ${isSeen ? 'bg-rose/50' : 'bg-lav/40'}`} />
                  <Star className={`relative h-8 w-8 ${isSeen ? 'text-rose-soft' : 'text-ivory'}`} fill="currentColor" aria-hidden="true" />
                  {isSeen && <Sparkles className="absolute -right-2 -top-2 h-4 w-4 text-gold" aria-hidden="true" />}
                </span>
                {selected === i && <span aria-hidden="true" className="absolute h-14 w-14 rounded-full border-2 border-gold" />}
              </button>
            );
          })}
          <button type="button" onClick={() => open(6)} aria-pressed={selected === 6} aria-label={W.lastWishLabel}
            className="absolute flex -translate-x-1/2 -translate-y-1/2 flex-col items-center gap-1 rounded-2xl p-2 active:scale-95"
            style={{ left: `${GOLD.x}%`, top: `${GOLD.y}%` }}>
            <span className="relative grid place-items-center animate-glow">
              <span aria-hidden="true" className="absolute h-16 w-16 rounded-full bg-gold/50 blur-lg" />
              <Star className="relative h-11 w-11 text-gold" fill="currentColor" aria-hidden="true" />
            </span>
            <span className="whitespace-nowrap text-[13px] font-medium text-gold-soft">{W.lastWishLabel}</span>
          </button>
          </div>

          <div aria-live="polite" className="flex min-h-[150px] flex-col items-center justify-center border-t border-gold/25 bg-night-900/60 px-5 py-5 text-center">
            <AnimatePresence mode="wait">
              {text ? (
                <motion.p key={selected} initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }} transition={{ duration: 0.5 }}
                  className={`max-w-lg font-serif text-2xl italic leading-snug sm:text-3xl ${selected === 6 ? 'text-gold-soft' : 'text-ivory'}`}>
                  {text}
                </motion.p>
              ) : (
                <motion.p key="hint" className="text-base text-ivory/75" exit={{ opacity: 0 }}>Your wishes are waiting in the stars.</motion.p>
              )}
            </AnimatePresence>
            <p className="mt-3 text-sm text-ivory/75">{Math.min(seen.size - (seen.has(6) ? 1 : 0), POS.length)} of {POS.length} wishes opened</p>
          </div>
        </div>

      </div>
    </section>
  );
}
