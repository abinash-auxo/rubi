import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Flame, PartyPopper, RotateCcw, Wand2, Wind } from 'lucide-react';
import { config } from '../data/birthdayConfig';
import { fireConfetti } from '../lib/confetti';
import { prefersReducedMotion, scrollToId } from '../lib/motion';
import Cake from './Cake';
import Petals from './Petals';
import SectionHeading from './SectionHeading';

type Step = 0 | 1 | 2 | 3 | 4; // 0 unlit, 1 lit, 2 wish made, 3 blown out, 4 celebrated

/** Chapter 8: the cake finale. */
export default function BirthdayFinale({ onReplay }: { onReplay: () => void }) {
  const F = config.finale;
  const [step, setStep] = useState<Step>(0);
  const [smoke, setSmoke] = useState(false);

  const msgRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (step !== 4) return;
    const t = window.setTimeout(() => msgRef.current?.scrollIntoView({ behavior: prefersReducedMotion() ? 'auto' : 'smooth', block: 'center' }), 1000);
    return () => window.clearTimeout(t);
  }, [step]);

  const lit = step === 1 || step === 2;
  const hints: Record<Step, string> = {
    0: 'Start by lighting the candles.',
    1: 'Now make a wish.',
    2: 'Ready? Blow out the candles.',
    3: 'Press Celebrate!',
    4: '',
  };

  const blow = () => {
    setStep(3);
    setSmoke(true);
    window.setTimeout(() => setSmoke(false), 2200);
  };
  const celebrate = () => {
    setStep(4);
    fireConfetti({ origin: { x: 0.5, y: 0.7 } });
    window.setTimeout(() => fireConfetti({ origin: { x: 0.2, y: 0.8 }, count: 70 }), 450);
    window.setTimeout(() => fireConfetti({ origin: { x: 0.8, y: 0.8 }, count: 70 }), 800);
  };

  const labels = ['Light', 'Wish', 'Blow out', 'Celebrate'];

  return (
    <section id="finale" aria-label="Birthday finale" className="relative overflow-hidden px-5 py-24 pb-36">
      <Petals />
      <div className="relative z-10">
        <SectionHeading chapter="Chapter 8" title={F.heading} subtitle={F.message} />
        <div className="mx-auto flex max-w-xl flex-col items-center">
          <div className="relative">
            <div aria-hidden="true" className={`absolute left-1/2 top-[20%] h-72 w-72 -translate-x-1/2 rounded-full blur-2xl transition-opacity duration-700 ${lit || step === 4 ? 'opacity-100' : 'opacity-30'}`}
              style={{ background: 'radial-gradient(circle, rgba(246,223,174,.4), transparent 68%)' }} />
            <Cake lit={lit || step === 4} smoke={smoke} className="relative w-72 sm:w-96" />
          </div>

          <ol className="mt-6 flex items-center gap-2 p-0 text-[13px] text-ivory/80" aria-label="Progress">
            {labels.map((l, i) => (
              <li key={l} className={`whitespace-nowrap rounded-full border px-2.5 py-1 sm:px-3 ${step > i ? 'border-gold bg-gold/15 text-gold-soft' : 'border-ivory/30'}`}>
                {step > i ? '✓ ' : ''}{l}
              </li>
            ))}
          </ol>

          <div className="mt-6 grid w-full max-w-md grid-cols-1 gap-3 sm:grid-cols-2">
            <button type="button" className="btn btn-primary" disabled={step !== 0} onClick={() => setStep(1)}><Flame className="h-5 w-5" aria-hidden="true" /> Light the Candles</button>
            <button type="button" className="btn btn-ghost" disabled={step !== 1} onClick={() => setStep(2)}><Wand2 className="h-5 w-5" aria-hidden="true" /> Make a Wish</button>
            <button type="button" className="btn btn-ghost" disabled={step !== 2} onClick={blow}><Wind className="h-5 w-5" aria-hidden="true" /> Blow Out the Candles</button>
            <button type="button" className="btn btn-gold" disabled={step !== 3} onClick={celebrate}><PartyPopper className="h-5 w-5" aria-hidden="true" /> Celebrate!</button>
          </div>

          <div aria-live="polite" className="mt-6 min-h-[64px] text-center">
            {step === 2 && <p className="font-serif text-2xl italic text-gold-soft">{F.wishPrompt}</p>}
            {step !== 2 && step !== 4 && <p className="text-base text-ivory/80">{hints[step]}</p>}
          </div>

          <AnimatePresence>
            {step === 4 && (
              <motion.div ref={msgRef} initial={{ opacity: 0, y: 28 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.9 }} className="glass mt-2 w-full rounded-3xl p-7 text-center sm:p-9">
                <p className="font-serif text-2xl italic leading-snug text-ivory sm:text-3xl">{F.finalPersonalMessage}</p>
                <div className="mt-7 flex flex-col items-center justify-center gap-3 sm:flex-row">
                  <button type="button" className="btn btn-primary" onClick={onReplay}><RotateCcw className="h-4 w-4" aria-hidden="true" /> Replay the surprise</button>
                  <button type="button" className="btn btn-ghost" onClick={() => scrollToId('hero')}>Back to the beginning</button>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
