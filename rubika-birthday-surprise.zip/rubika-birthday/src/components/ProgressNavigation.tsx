import { scrollToId } from '../lib/motion';

export const CHAPTERS = [
  { id: 'intro', label: 'The Invitation' },
  { id: 'hero', label: 'The Reveal' },
  { id: 'letter', label: 'Your Letter' },
  { id: 'wishes', label: 'Wishes' },
  { id: 'celebrate', label: 'Worth Celebrating' },
  { id: 'gallery', label: 'Our Little Universe' },
  { id: 'treasure', label: 'Treasure Hunt' },
  { id: 'finale', label: 'The Finale' },
] as const;

export const SECTION_IDS = CHAPTERS.slice(1).map((c) => c.id);

interface Props { active: string; onReplayIntro: () => void }

/** Discreet chapter dots: bottom bar on phones, right edge on larger screens. */
export default function ProgressNavigation({ active, onReplayIntro }: Props) {
  const current = CHAPTERS.find((c) => c.id === active)?.label ?? '';
  return (
    <nav aria-label="Chapters"
      className="fixed bottom-[max(0.75rem,env(safe-area-inset-bottom))] left-1/2 z-40 flex -translate-x-1/2 flex-col items-center gap-2 md:bottom-auto md:left-auto md:right-4 md:top-1/2 md:-translate-x-0 md:-translate-y-1/2">
      <p className="glass rounded-full px-3 py-1 text-[13px] text-ivory md:hidden" aria-hidden="true">{current}</p>
      <ul className="glass m-0 flex list-none items-center gap-0 rounded-full p-1 md:flex-col">
        {CHAPTERS.map((c, i) => {
          const isActive = c.id === active;
          return (
            <li key={c.id}>
              <button type="button" title={c.label} aria-label={i === 0 ? `Replay the opening: ${c.label}` : `Go to ${c.label}`}
                aria-current={isActive ? 'step' : undefined}
                onClick={() => (i === 0 ? onReplayIntro() : scrollToId(c.id))}
                className="grid h-8 w-8 place-items-center rounded-full">
                <span className={`block rounded-full transition-all ${isActive ? 'h-3 w-3 bg-gold ring-2 ring-gold/40' : i === 0 ? 'h-2 w-2 border border-ivory/80' : 'h-2 w-2 bg-ivory/55'}`} />
              </button>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
