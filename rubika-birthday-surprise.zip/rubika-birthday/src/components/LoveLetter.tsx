import { useEffect, useMemo, useState } from 'react';
import { AnimatePresence, motion, useReducedMotion } from 'framer-motion';
import { Heart, MailOpen } from 'lucide-react';
import { config } from '../data/birthdayConfig';
import EnvelopeGraphic from './EnvelopeGraphic';
import SectionHeading from './SectionHeading';

type Phase = 'sealed' | 'opening' | 'reading';

/** Chapter 3: the love letter. Edit the words in src/data/birthdayConfig.ts */
export default function LoveLetter() {
  const L = config.letter;
  const reduce = useReducedMotion();
  const [phase, setPhase] = useState<Phase>('sealed');
  const [count, setCount] = useState(0);
  const [kept, setKept] = useState(0);

  const lines = useMemo(() => [L.salutation, ...L.paragraphs, L.closing, L.signature], [L]);
  const total = useMemo(() => lines.reduce((n, l) => n + l.length, 0), [lines]);
  const done = count >= total;

  useEffect(() => {
    if (phase !== 'opening') return;
    const t = window.setTimeout(() => setPhase('reading'), reduce ? 100 : 1500);
    return () => window.clearTimeout(t);
  }, [phase, reduce]);

  useEffect(() => {
    if (phase !== 'reading') return;
    if (reduce) { setCount(total); return; }
    const id = window.setInterval(() => setCount((c) => Math.min(total, c + 2)), 24);
    return () => window.clearInterval(id);
  }, [phase, reduce, total]);

  let remaining = count;
  const shown = lines.map((l) => {
    const take = Math.max(0, Math.min(l.length, remaining));
    remaining -= take;
    return [l.slice(0, take), l.slice(take)] as const;
  });

  return (
    <section id="letter" aria-label="A letter for you" className="relative px-5 py-24 pb-28">
      <SectionHeading chapter="Chapter 3" title={L.heading} />
      <div className="mx-auto flex max-w-xl flex-col items-center">
        <AnimatePresence mode="wait">
          {phase !== 'reading' ? (
            <motion.div key="env" exit={{ opacity: 0, scale: 0.9 }} transition={{ duration: 0.4 }} className="flex flex-col items-center gap-10">
              <EnvelopeGraphic open={phase === 'opening'} label={config.recipientName} className="mt-16" />
              <button type="button" className="btn btn-primary" disabled={phase === 'opening'} onClick={() => setPhase('opening')}>
                <MailOpen className="h-5 w-5" aria-hidden="true" /> {L.openButton}
              </button>
            </motion.div>
          ) : (
            <motion.article key="paper" initial={{ opacity: 0, y: 40, scale: 0.96 }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ duration: 0.9, ease: 'easeOut' }}
              className="relative w-full rounded-lg bg-ivory px-6 py-9 text-[#3a1f4d] shadow-[0_0_80px_rgba(240,112,159,0.3),0_30px_60px_rgba(0,0,0,0.45)] sm:px-12 sm:py-12">
              <div aria-hidden="true" className="pointer-events-none absolute inset-3 rounded border border-gold-deep/40" />
              <div className="sr-only-copy">{lines.join('\n')}</div>
              <div aria-hidden="true" className="relative space-y-5 font-serif text-[1.3rem] font-medium italic leading-[1.7] sm:text-[1.45rem]">
                {shown.map(([seen, unseen], i) => (
                  <p key={i} className={i === lines.length - 2 ? 'pt-3' : i === lines.length - 1 ? '!mt-1 text-[1.6rem] text-rose-dark' : ''}>
                    <span>{seen}</span><span className="invisible">{unseen}</span>
                  </p>
                ))}
              </div>
            </motion.article>
          )}
        </AnimatePresence>

        {phase === 'reading' && (
          <div className="relative mt-8 flex min-h-[110px] flex-col items-center gap-4">
            {!done ? (
              <button type="button" className="btn btn-ghost" onClick={() => setCount(total)}>Show the whole letter</button>
            ) : (
              <motion.button type="button" className="btn btn-primary" initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} onClick={() => setKept((k) => k + 1)}>
                <Heart className="h-5 w-5" fill="currentColor" aria-hidden="true" /> {L.keepButton}
              </motion.button>
            )}
            <div aria-live="polite" className="min-h-[28px] text-center font-serif text-xl italic text-gold-soft">
              {kept > 0 && <motion.span key={kept} initial={{ opacity: 0 }} animate={{ opacity: 1 }}>{L.keepMessage}</motion.span>}
            </div>
            {kept > 0 && !reduce && Array.from({ length: 8 }, (_, i) => (
              <motion.span key={`${kept}-${i}`} aria-hidden="true" className="pointer-events-none absolute bottom-[70px] left-1/2 text-rose"
                initial={{ opacity: 1, y: 0, x: 0, scale: 0.6 }}
                animate={{ opacity: 0, y: -110 - (i % 3) * 25, x: (i - 3.5) * 22, scale: 1.2 }}
                transition={{ duration: 1.6, delay: i * 0.06, ease: 'easeOut' }}>
                <Heart className="h-5 w-5" fill="currentColor" />
              </motion.span>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
