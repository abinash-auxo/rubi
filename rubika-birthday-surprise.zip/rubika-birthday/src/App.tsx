import { useCallback, useState } from 'react';
import { AnimatePresence, MotionConfig } from 'framer-motion';
import BirthdayFinale from './components/BirthdayFinale';
import BirthdayHero from './components/BirthdayHero';
import IntroScene from './components/IntroScene';
import LoveLetter from './components/LoveLetter';
import MemoryGallery from './components/MemoryGallery';
import MusicPlayer from './components/MusicPlayer';
import ProgressNavigation, { SECTION_IDS } from './components/ProgressNavigation';
import SpecialQualities from './components/SpecialQualities';
import StarField from './components/StarField';
import TreasureHunt from './components/TreasureHunt';
import WishConstellation from './components/WishConstellation';
import { useActiveSection } from './hooks/useActiveSection';

export default function App() {
  const [introDone, setIntroDone] = useState(false);
  const active = useActiveSection(SECTION_IDS, introDone);

  const finishIntro = useCallback(() => {
    window.scrollTo({ top: 0 });
    setIntroDone(true);
  }, []);
  const replay = useCallback(() => {
    window.scrollTo({ top: 0 });
    setIntroDone(false);
  }, []);

  return (
    <MotionConfig reducedMotion="user">
      <div aria-hidden="true" className="sky-bg fixed inset-0 -z-20" />
      <StarField />
      <MusicPlayer />
      <AnimatePresence>{!introDone && <IntroScene key="intro" onFinish={finishIntro} />}</AnimatePresence>
      {introDone && (
        <>
          <ProgressNavigation active={active} onReplayIntro={replay} />
          <main className="relative overflow-x-clip">
            <BirthdayHero />
            <LoveLetter />
            <WishConstellation />
            <SpecialQualities />
            <MemoryGallery />
            <TreasureHunt />
            <BirthdayFinale onReplay={replay} />
          </main>
        </>
      )}
    </MotionConfig>
  );
}
