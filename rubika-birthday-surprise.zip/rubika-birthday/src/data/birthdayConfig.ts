/**
 * ============================================================================
 *  RUBIKA'S BIRTHDAY SURPRISE: PERSONALIZATION FILE
 * ============================================================================
 *  Everything she will read lives in THIS file. You never need to search the
 *  rest of the code. Edit the text between the quotation marks, save, and the
 *  page updates (npm run dev) or rebuild it (npm run build) before you share it.
 *
 *  Rules of thumb
 *   - Keep each text inside straight quotes ("like this").
 *   - If your text contains a double quote, write it as \" or use single quotes.
 *   - Emojis are fine.
 *   - Do not put passwords or private information in here: the finished
 *     website is public to anyone who has the link.
 * ============================================================================
 */

export interface WishStar { text: string }
export interface Quality {
  title: string;
  icon: 'smile' | 'heart' | 'sparkles' | 'mountain' | 'fingerprint' | 'flower';
  message: string;
}
export interface GalleryItem { src: string; alt: string; caption: string }
export interface Clue { id: 'heart' | 'star' | 'gift'; label: string; prompt: string; found: string }

export const config = {
  // ---------------------------------------------------------------- 1. BASICS
  recipientName: 'Rubika',
  /** Used only for the page title and the cake line. The site never shows an age. */
  birthday: { dateOfBirth: '2007-10-19', display: '19 October' },

  // --------------------------------------------------------- 2. OPENING SCENE
  intro: {
    teaser: 'Someone has created something special for you...',
    button: 'Open Your Surprise ✨',
    afterOpen: 'This little universe was made just for you, Rubika.',
  },

  // ----------------------------------------------------------- 3. BIRTHDAY HERO
  hero: {
    greetingLine: 'Happy Birthday,',
    message:
      'Today, the world gets to celebrate someone who makes it a little more beautiful just by being herself.',
    primaryButton: 'Your Surprise Awaits 💝',
    wishButton: 'Make a Birthday Wish',
    wishTitle: 'Make a wish, Rubika',
    wishInstructions: 'Close your eyes, take a deep breath, and think of something you hope for this year.',
    wishAfter: 'Wish made. I hope it comes true, every single bit of it. 💫',
  },

  // -------------------------------------------------------------- 4. LOVE LETTER
  // EDIT THE LETTER HERE. Each line in `paragraphs` is one paragraph.
  letter: {
    heading: 'A letter written just for you',
    openButton: 'Open the letter',
    salutation: 'Dear Rubika,',
    paragraphs: [
      'Happy Birthday to someone who deserves all the beautiful things this world has to offer.',
      'Today is all about you — your happiness, your dreams, your smile, and all the wonderful moments still waiting for you.',
      'I hope this new chapter of your life brings you endless reasons to smile, the courage to chase everything you dream of, and little moments that make your heart feel full.',
      'You deserve to feel celebrated, appreciated, and loved — not just today, but throughout the year.',
      'No matter how busy life gets, I hope you always remember how special you are.',
      'Keep smiling, keep dreaming, and keep being wonderfully you.',
    ],
    closing: 'With lots of love,',
    signature: 'Your favorite person ❤️',
    keepButton: 'Keep This Letter Close',
    keepMessage: 'A little reminder, whenever you need it ❤️',
  },

  // ------------------------------------------------------------ 5. WISH GALAXY
  wishes: {
    heading: 'A galaxy of beautiful wishes',
    subtitle: 'Tap a star to open a wish.',
    stars: [
      { text: 'May your dreams grow bigger than your fears.' },
      { text: 'May you find happiness in the smallest moments.' },
      { text: 'May life surprise you with beautiful opportunities.' },
      { text: 'May you always have the courage to be yourself.' },
      { text: 'May your smile find a thousand reasons to return.' },
      { text: 'May this year bring you closer to everything your heart desires.' },
    ] as WishStar[],
    lastWishLabel: 'One Last Wish',
    lastWish: 'And my biggest wish is that life gives you every beautiful thing your heart has been hoping for.',
  },

  // ------------------------------------------------- 6. THINGS WORTH CELEBRATING
  // Keep these general unless you want to add real, specific details about her.
  qualities: {
    heading: 'Things worth celebrating about you',
    subtitle: 'Tap a card to turn it over.',
    items: [
      { title: 'Your Smile', icon: 'smile', message: 'I hope life gives you countless reasons to smile, today and every day.' },
      { title: 'Your Kind Heart', icon: 'heart', message: 'May the kindness you give find its way back to you, again and again.' },
      { title: 'Your Dreams', icon: 'sparkles', message: 'Keep dreaming big. The world is better with your dreams in it.' },
      { title: 'Your Strength', icon: 'mountain', message: 'On easy days and hard ones, I hope you always remember how strong you are.' },
      { title: 'Your Unique Way of Being', icon: 'fingerprint', message: 'There is only one you, and that is something truly worth celebrating.' },
      { title: 'The Little Things That Make You, You', icon: 'flower', message: 'Every little thing that makes you who you are deserves to be cherished.' },
    ] as Quality[],
  },

  // -------------------------------------------------------------- 7. PHOTO GALLERY
  // HOW TO ADD PHOTOS
  //   1. Copy your photos into the folder  public/images/
  //   2. Name them photo-1.jpg ... photo-6.jpg  (or change the "src" below)
  //   3. Write a caption (or leave "" for none) and a short description in "alt"
  //      (alt text is read aloud for people using screen readers).
  // Missing photos simply show a pretty placeholder.
  gallery: {
    heading: 'Our Little Universe',
    subtitle: 'Moments worth keeping.',
    items: [
      { src: 'images/photo-1.jpg', alt: 'Photo 1 of us', caption: '' },
      { src: 'images/photo-2.jpg', alt: 'Photo 2 of us', caption: '' },
      { src: 'images/photo-3.jpg', alt: 'Photo 3 of us', caption: '' },
      { src: 'images/photo-4.jpg', alt: 'Photo 4 of us', caption: '' },
      { src: 'images/photo-5.jpg', alt: 'Photo 5 of us', caption: '' },
      { src: 'images/photo-6.jpg', alt: 'Photo 6 of us', caption: '' },
    ] as GalleryItem[],
  },

  // ------------------------------------------------------------ 8. TREASURE HUNT
  treasure: {
    title: 'One Last Surprise Is Hidden Here...',
    intro: 'Slide your finger (or mouse) across the dark sky to light it up. Three little things are hiding.',
    lockedMessage: 'The golden box is still locked. Find the glowing heart and the hidden star first.',
    clues: [
      { id: 'heart', label: 'Glowing heart', prompt: 'Clue 1: Something warm is glowing in the dark. Find the glowing heart.', found: 'You found the glowing heart! Great eyes, Rubika.' },
      { id: 'star', label: 'Hidden star', prompt: 'Clue 2: A tiny wish is hiding among the stars. Discover the hidden star.', found: 'The hidden star is yours. One more to go!' },
      { id: 'gift', label: 'Golden gift box', prompt: 'Clue 3: The golden gift box is waiting at the bottom. Tap it to unlock your surprise.', found: 'Click... the lock opens.' },
    ] as Clue[],
    finalMessage:
      'You found it, Rubika! Your final birthday surprise is a reminder that you deserve beautiful things, wonderful memories, and all the happiness this new year can bring.',
  },

  // --------------------------------------------------------------- 9. FINALE
  finale: {
    heading: 'Happy Birthday, Rubika ❤️',
    message:
      'May your 19th October be the beginning of a year filled with happiness, growth, beautiful surprises, and unforgettable moments.',
    wishPrompt: 'Close your eyes and make your wish...',
    /** Shown after she presses "Celebrate!". Write something only you could say. */
    finalPersonalMessage:
      'However today unfolds, I hope you feel exactly how loved you are. Happy Birthday, Rubika. ❤️',
  },

  // ------------------------------------------------------------- 10. MUSIC
  // Put your file at  public/audio/birthday.mp3  (see public/audio/README.txt).
  // Set src to "" to hide the music button's audio entirely.
  music: { src: 'audio/birthday.mp3', unavailableMessage: "Music isn't available right now." },
};

export type BirthdayConfig = typeof config;
