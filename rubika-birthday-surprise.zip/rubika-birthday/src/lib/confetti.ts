import { prefersReducedMotion } from './motion';

const COLORS = ['#f0709f', '#f9a8c6', '#e8c785', '#cdbdf2', '#fbf3e6', '#c2417a'];

interface Options { count?: number; origin?: { x: number; y: number }; power?: number }

/** Lightweight canvas confetti (no library). Removes itself when finished. */
export function fireConfetti({ count, origin, power = 1 }: Options = {}): void {
  if (typeof window === 'undefined' || prefersReducedMotion()) return;
  const w = window.innerWidth;
  const h = window.innerHeight;
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  const canvas = document.createElement('canvas');
  canvas.width = w * dpr;
  canvas.height = h * dpr;
  Object.assign(canvas.style, { position: 'fixed', inset: '0', width: '100%', height: '100%', pointerEvents: 'none', zIndex: '90' });
  canvas.setAttribute('aria-hidden', 'true');
  document.body.appendChild(canvas);
  const ctx = canvas.getContext('2d');
  if (!ctx) { canvas.remove(); return; }
  ctx.scale(dpr, dpr);

  const n = count ?? (w < 640 ? 90 : 150);
  const ox = (origin?.x ?? 0.5) * w;
  const oy = (origin?.y ?? 0.6) * h;
  const parts = Array.from({ length: n }, () => {
    const a = -Math.PI / 2 + (Math.random() - 0.5) * Math.PI * 1.15;
    const s = (6 + Math.random() * 9) * power;
    return {
      x: ox, y: oy, vx: Math.cos(a) * s, vy: Math.sin(a) * s,
      size: 5 + Math.random() * 6, color: COLORS[Math.floor(Math.random() * COLORS.length)],
      rot: Math.random() * 6.28, vr: (Math.random() - 0.5) * 0.3, heart: Math.random() < 0.18,
    };
  });

  const maxFrames = 240;
  let frame = 0;
  const tick = () => {
    frame++;
    ctx.clearRect(0, 0, w, h);
    ctx.globalAlpha = Math.max(0, 1 - frame / maxFrames);
    for (const p of parts) {
      p.vy += 0.22; p.vx *= 0.99; p.x += p.vx; p.y += p.vy; p.rot += p.vr;
      ctx.fillStyle = p.color;
      ctx.save();
      ctx.translate(p.x, p.y);
      ctx.rotate(p.rot);
      if (p.heart) {
        const s = p.size / 2;
        ctx.beginPath();
        ctx.moveTo(0, s * 0.4);
        ctx.bezierCurveTo(-s * 1.4, -s * 0.6, -s * 0.5, -s * 1.4, 0, -s * 0.5);
        ctx.bezierCurveTo(s * 0.5, -s * 1.4, s * 1.4, -s * 0.6, 0, s * 0.4);
        ctx.fill();
      } else {
        ctx.fillRect(-p.size / 2, -p.size / 4, p.size, p.size / 2);
      }
      ctx.restore();
    }
    if (frame < maxFrames) requestAnimationFrame(tick);
    else canvas.remove();
  };
  requestAnimationFrame(tick);
}
