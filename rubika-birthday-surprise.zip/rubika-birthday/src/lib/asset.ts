/** Turns "images/photo-1.jpg" into a URL that works locally and on any host. */
export function asset(path: string): string {
  if (/^(https?:)?\/\//.test(path) || path.startsWith('data:')) return path;
  const base = import.meta.env.BASE_URL || '/';
  return base + path.replace(/^\/+/, '');
}
