/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: {
    extend: {
      colors: {
        night: { 950: '#07030f', 900: '#0d0720', 800: '#150b2e', 700: '#1f1141', 600: '#2a1857' },
        rose: { DEFAULT: '#f0709f', soft: '#f9a8c6', deep: '#c2417a', dark: '#9d2a62' },
        gold: { DEFAULT: '#e8c785', deep: '#c9a15a', soft: '#f6dfae' },
        lav: { DEFAULT: '#cdbdf2', deep: '#9d86d6' },
        ivory: '#fbf3e6',
      },
      fontFamily: {
        serif: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        sans: ['Jost', 'system-ui', 'sans-serif'],
        script: ['"Pinyon Script"', '"Cormorant Garamond"', 'cursive'],
      },
      keyframes: {
        float: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-10px)' } },
        twinkle: { '0%,100%': { opacity: '1', transform: 'scale(1)' }, '50%': { opacity: '.55', transform: 'scale(.86)' } },
        flicker: {
          '0%,100%': { transform: 'scale(1,1) skewX(0deg)' },
          '35%': { transform: 'scale(.92,1.1) skewX(2deg)' },
          '70%': { transform: 'scale(1.05,.95) skewX(-2deg)' },
        },
        petal: {
          '0%': { transform: 'translate3d(0,-8vh,0) rotate(0deg)', opacity: '0' },
          '10%': { opacity: '.85' },
          '90%': { opacity: '.85' },
          '100%': { transform: 'translate3d(var(--drift,40px),110vh,0) rotate(540deg)', opacity: '0' },
        },
        glow: { '0%,100%': { opacity: '.55', transform: 'scale(1)' }, '50%': { opacity: '.9', transform: 'scale(1.08)' } },
        bars: { '0%,100%': { transform: 'scaleY(.35)' }, '50%': { transform: 'scaleY(1)' } },
        shake: { '0%,100%': { transform: 'translateX(0)' }, '25%': { transform: 'translateX(-5px)' }, '75%': { transform: 'translateX(5px)' } },
      },
      animation: {
        float: 'float 6s ease-in-out infinite',
        twinkle: 'twinkle 3s ease-in-out infinite',
        flicker: 'flicker 0.9s ease-in-out infinite',
        petal: 'petal 16s linear infinite',
        glow: 'glow 5s ease-in-out infinite',
        bars: 'bars 0.9s ease-in-out infinite',
        shake: 'shake 0.35s ease-in-out',
      },
    },
  },
  plugins: [],
};
